/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Dell
 */
public class Student {
    String name;
    String department;
    int rollno;
    
    //default constructor
     public Student() {
        this.name = "Unknown";
        this.department = "unknown";
        this.rollno = 0;
    }
    //parameterized constructor
      public Student(String name, String department, int rollno) {
        this.name = name;
        this.department = department;
        this.rollno = rollno;
      }
    //copy constructor
    public Student(Student another){
        this.name = another.name;
        this.department = another.department;
        this.rollno = another.rollno;
    }
    public void takeInput() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter student name:");
        this.name = scanner.nextLine();

        System.out.println("Enter student department:");
        this.department = scanner.nextLine();

        System.out.println("Enter student roll number:");
        this.rollno = scanner.nextInt();
    }
 
    public void Display(){
        System.out.println("Student Name: " + this.name);
        System.out.println("Student Age: " + this.department);
        System.out.println("Student Roll Number: " + this.rollno);
    }
    public static void main(String[] args){
       Student student1 = new Student();
        System.out.println("Enter details for student1");
        student1.takeInput();  // Taking input from user for student1
        System.out.println("\nDetails of student1:");
        student1.Display();  // Displaying details of student 1
        
        Student student2 = new Student();
        System.out.println("\nEnter details for student2:");
        student2.takeInput();  // Taking input from user for student2
        System.out.println("\nDetails of student2:");
        student2.Display();  // Displaying details of student2
        
        // Creating a third student object using copy constructor
        Student student3 = new Student(student2);
        System.out.println("\nDetails of student3 (copy of studentalish2):");
        student3.Display();  // Displaying details of copied student
    }  
}
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.util.Scanner;
/**
 *
 * @author Dell
 */
public class Department {
     String departmentName;
     String departmentHead;

    // Default constructor
    public Department() {
        this.departmentName = "Unknown";
        this.departmentHead = "Unknown";
    }
    // Parameterized constructor
    public Department(String departmentName, String departmentHead) {
        this.departmentName = departmentName;
        this.departmentHead = departmentHead;
    }

    // Copy constructor
    public Department(Department other) {
        this.departmentName = other.departmentName;
        this.departmentHead = other.departmentHead;
    }

    public void takeInput() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("\nEnter Department Name: ");
        departmentName = scanner.nextLine();
        System.out.print("Enter Department Head: ");
        departmentHead = scanner.nextLine();
    }

    public void display() {
        System.out.println("\nDepartment Details:");
        System.out.println("Department Name: " + departmentName);
        System.out.println("Department Head: " + departmentHead);
    }
     public static void main(String[] args) {
         
        Department dept1 = new Department();
        dept1.takeInput();
        System.out.println("\nUser Input:");
        dept1.display();
        
        // Create Department object using the default constructor
        Department dept2 = new Department();
        dept1.takeInput();
        System.out.println("Default constructor:");
        dept2.display();

        // Create Department object using parameterized constructor
        Department dept3 = new Department("Human Resources", "Alice jhon");
        System.out.println("\nUsing Parameterized Constructor:");
        dept3.display();

        // Create Department object using copy constructor
        Department dept4 = new Department(dept3);
        System.out.println("\nUsing Copy Constructor:");
        dept3.display();
    }
}

